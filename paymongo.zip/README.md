# Plugin template

* This is a sample plugin with no functionality, it just adds a new log entry when executed.
* It can be used by developers as a template for creating a new plugin.  

Read more about creating your own plugin in the [Developer documentation](https://github.com/Ubiquiti-App/UCRM-plugins/blob/master/docs/index.md).

