<?php

namespace Sweeeeep\PaymongoUcrm\Data;

class UcrmData {

    public $pluginAppKey;

    public $ucrmPublicUrl;

    public $ucrmLocalUrl;

    public $pluginPublicUrl;

}